<?php  


// include "C:\xampp\htdocs\main works\Atended_system\config.php";
include "../../config.php";



?>